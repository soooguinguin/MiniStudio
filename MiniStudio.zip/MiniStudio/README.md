# Mini Studio

Un mini Roblox Studio pour Android. Pas de builder, pas de terrain, pas de
multijoueur : juste ce qu'il faut pour **poser des Parts et tester des scripts**.
100 % hors ligne, aucune permission réseau, tout est stocké dans l'app.

## Les 5 panneaux

| Panneau | Ce que ça fait |
|---|---|
| **Viewport 3D** | 1 doigt = tourner la caméra, 2 doigts = zoom, tap = sélectionner une Part |
| **Explorer** | arbre `game > Workspace / Lighting / ReplicatedStorage / ServerScriptService`, pliable, bouton **+ Insérer**, appui long = renommer / dupliquer / supprimer |
| **Propriétés** | Name, ClassName + toutes les propriétés de l'instance. Tap = éditer (booléen = bascule directe, Face = liste) |
| **Attributs** | `SetAttribute` / `GetAttribute` comme dans Roblox. Bouton **+ Ajouter** (Texte / Nombre / Booléen / Vector3 / Color3), appui long = supprimer |
| **Script** | éditeur monospace de la propriété `Source` du Script sélectionné |
| **Output** | `print` en gris, `warn` en orange, erreurs en rouge, avec le nom du script |

## Classes disponibles

`Part`, `Model`, `Folder`, `SurfaceGui`, `TextLabel`, `Frame`, `Script`,
`LocalScript`, `Value`.

- **Part** : Position, Size, Orientation, Color, Transparency, Anchored, CanCollide
- **SurfaceGui** : Face (Front/Back/Top/Bottom/Left/Right), Enabled — s'affiche vraiment sur la face de la Part dans le viewport
- **TextLabel** : Text, TextColor3, BackgroundColor3, BackgroundTransparency, TextSize

## Lua

C'est du vrai Lua (moteur LuaJ embarqué), pas une simulation. Ce qui marche :

```lua
-- globals
game, workspace, print, warn, wait(t), task.wait(t), task.spawn(f)

-- constructeurs
Instance.new("Part")            -- ou Instance.new("Part", workspace)
Vector3.new(x, y, z)
Color3.new(r, g, b)             -- 0..1
Color3.fromRGB(r, g, b)         -- 0..255

-- sur une instance
inst.Name, inst.ClassName, inst.Parent
inst:FindFirstChild(nom)
inst:WaitForChild(nom)
inst:GetChildren()
inst:GetDescendants()
inst:Destroy()
inst:Clone()
inst:IsA("BasePart")
inst:SetAttribute(nom, valeur)
inst:GetAttribute(nom)
inst:GetAttributes()

-- acces direct a un enfant par son nom
workspace.Part.SurfaceGui.TextLabel.Text = "Salut"
```

Exemple (déjà présent dans `ServerScriptService.DemoScript`) :

```lua
local part = workspace:FindFirstChild("Part")
for i = 1, 20 do
    part.Orientation = Vector3.new(0, i * 18, 0)
    part.Color = Color3.fromRGB(255 - i * 10, 40, i * 10)
    part.SurfaceGui.TextLabel.Text = "Tick " .. i
    task.wait(0.1)
end
```

**▶ Run** lance tous les Scripts activés du jeu. **■ Stop** les arrête (même
une boucle infinie). Le viewport se met à jour en direct pendant l'exécution.

## Compiler l'APK

1. Installe **Android Studio** : https://developer.android.com/studio
2. `File > Open` → choisis le dossier `MiniStudio`
3. Laisse la synchronisation Gradle se faire (elle télécharge LuaJ et les
   librairies AndroidX — c'est le seul moment où il faut internet)
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)`
5. L'APK sort dans `app/build/outputs/apk/debug/app-debug.apk`

## Limites assumées

- Les Parts sont uniquement des blocs (pas de sphères, cylindres, meshes)
- Pas de physique : `Anchored` et `CanCollide` sont stockés mais rien ne tombe
- Les SurfaceGui sont rendues en simplifié : le fond remplit la face et le
  texte est centré (pas de UDim2 ni de positionnement libre)
- `task.spawn` s'exécute immédiatement, ce ne sont pas de vraies coroutines
- Pas d'events (`.Touched`, `.Changed`), pas de joueurs

## Idées pour la suite

- Coloration syntaxique Lua dans l'éditeur
- Gizmo de déplacement dans le viewport (glisser une Part)
- `.Touched` / `.Changed` via un système d'events
- Export / import du place en JSON

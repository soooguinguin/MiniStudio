package com.local.ministudio

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.io.File

class StudioActivity : AppCompatActivity() {

    private lateinit var viewport: ViewportView
    private lateinit var explorerAdapter: ExplorerAdapter
    private lateinit var propsAdapter: KeyValueAdapter
    private lateinit var attrsAdapter: KeyValueAdapter
    private lateinit var outputAdapter: OutputAdapter
    private lateinit var outputList: RecyclerView
    private lateinit var scriptEditor: EditText
    private lateinit var scriptTitle: TextView

    private lateinit var panels: List<View>
    private lateinit var tabs: List<Button>

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var lua: LuaRunner

    private val saveFile: File by lazy { File(filesDir, "place.json") }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_studio)

        loadPlace()

        viewport = findViewById(R.id.viewport)
        scriptEditor = findViewById(R.id.scriptEditor)
        scriptTitle = findViewById(R.id.scriptTitle)

        lua = LuaRunner { ui.post { viewport.invalidate(); refreshPanels() } }

        setupExplorer()
        setupProps()
        setupAttrs()
        setupOutput()
        setupTabs()
        setupToolbar()

        viewport.onSelect = {
            explorerAdapter.rebuild()
            refreshPanels()
        }

        Studio.onOutputChanged = {
            ui.post {
                outputAdapter.refresh()
                if (outputAdapter.lastIndex() >= 0) outputList.scrollToPosition(outputAdapter.lastIndex())
            }
        }
        Studio.onTreeChanged = { ui.post { explorerAdapter.rebuild(); viewport.invalidate() } }

        Studio.log("Mini Studio prêt. Sélectionne un Script puis appuie sur ▶ Run.")
        refreshPanels()
    }

    // ---------------------------------------------------------------- panneaux

    private fun setupTabs() {
        panels = listOf(
            findViewById<View>(R.id.panelExplorer),
            findViewById<View>(R.id.listProps),
            findViewById<View>(R.id.panelAttrs),
            findViewById<View>(R.id.panelScript),
            findViewById<View>(R.id.panelOutput)
        )
        tabs = listOf(
            findViewById<Button>(R.id.tabExplorer),
            findViewById<Button>(R.id.tabProps),
            findViewById<Button>(R.id.tabAttrs),
            findViewById<Button>(R.id.tabScript),
            findViewById<Button>(R.id.tabOutput)
        )
        for ((i, b) in tabs.withIndex()) b.setOnClickListener { showTab(i) }
        showTab(0)
    }

    private fun showTab(index: Int) {
        for ((i, p) in panels.withIndex()) p.visibility = if (i == index) View.VISIBLE else View.GONE
        for ((i, b) in tabs.withIndex()) {
            b.setTextColor(if (i == index) Color.parseColor("#3794FF") else Color.parseColor("#9AA3AC"))
        }
        refreshPanels()
    }

    private fun setupToolbar() {
        findViewById<Button>(R.id.btnRun).setOnClickListener {
            saveScriptEdits()
            showTab(4)
            lua.runAllScripts()
        }
        findViewById<Button>(R.id.btnStop).setOnClickListener { lua.stop() }
        findViewById<Button>(R.id.btnFocus).setOnClickListener { viewport.focusOnSelection() }
        findViewById<Button>(R.id.btnInsert).setOnClickListener { showInsertDialog() }
        findViewById<Button>(R.id.btnSaveScript).setOnClickListener {
            saveScriptEdits(); savePlace()
        }
        findViewById<Button>(R.id.btnRunThis).setOnClickListener {
            saveScriptEdits()
            val sel = Studio.selected
            if (sel != null && (sel.className == "Script" || sel.className == "LocalScript")) {
                showTab(4)
                lua.runScript(sel)
            } else Studio.log("Sélectionne d'abord un Script dans l'Explorer", 1)
        }
        findViewById<Button>(R.id.btnClearOutput).setOnClickListener { Studio.clearOutput() }
        findViewById<Button>(R.id.btnAddAttr).setOnClickListener { showAddAttributeDialog() }
    }

    // ---------------------------------------------------------------- explorer

    private fun setupExplorer() {
        val list = findViewById<RecyclerView>(R.id.listExplorer)
        list.layoutManager = LinearLayoutManager(this)
        explorerAdapter = ExplorerAdapter(
            onClick = { inst ->
                Studio.selected = inst
                explorerAdapter.rebuild()
                viewport.invalidate()
                refreshPanels()
            },
            onLongClick = { inst -> showInstanceMenu(inst) }
        )
        list.adapter = explorerAdapter
        explorerAdapter.rebuild()
    }

    private fun showInstanceMenu(inst: RInstance) {
        val options = arrayListOf("Renommer", "Dupliquer", "Insérer dedans")
        if (inst.parent != null) options.add("Supprimer")
        AlertDialog.Builder(this)
            .setTitle(inst.name)
            .setItems(options.toTypedArray()) { _, which ->
                when (options[which]) {
                    "Renommer" -> promptText("Renommer", inst.name) {
                        inst.name = it
                        explorerAdapter.rebuild(); viewport.invalidate(); refreshPanels()
                    }
                    "Dupliquer" -> {
                        val c = inst.clone()
                        c.setParent(inst.parent)
                        explorerAdapter.rebuild(); viewport.invalidate()
                    }
                    "Insérer dedans" -> { Studio.selected = inst; showInsertDialog() }
                    "Supprimer" -> {
                        if (Studio.selected === inst) Studio.selected = null
                        inst.destroy()
                        explorerAdapter.rebuild(); viewport.invalidate(); refreshPanels()
                    }
                }
            }.show()
    }

    private fun showInsertDialog() {
        val parent = Studio.selected ?: Studio.workspace
        val classes = RInstance.CREATABLE.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Insérer dans ${parent.name}")
            .setItems(classes) { _, which ->
                val inst = RInstance.new(classes[which])
                inst.setParent(parent)
                parent.expanded = true
                Studio.selected = inst
                explorerAdapter.rebuild()
                viewport.invalidate()
                refreshPanels()
            }.show()
    }

    // ---------------------------------------------------------------- properties

    private fun setupProps() {
        val list = findViewById<RecyclerView>(R.id.listProps)
        list.layoutManager = LinearLayoutManager(this)
        propsAdapter = KeyValueAdapter(onClick = { key -> editProperty(key) })
        list.adapter = propsAdapter
    }

    private fun editProperty(key: String) {
        val inst = Studio.selected ?: return

        if (key == "Name") {
            promptText("Name", inst.name) {
                inst.name = it; explorerAdapter.rebuild(); viewport.invalidate(); refreshPanels()
            }
            return
        }
        if (key == "ClassName") return

        val current = inst.props[key] ?: return

        if (current is Boolean) {
            inst.props[key] = !current
            viewport.invalidate(); refreshPanels()
            return
        }

        if (key == "Source") { showTab(3); return }

        if (key == "Face") {
            val faces = arrayOf("Front", "Back", "Top", "Bottom", "Left", "Right")
            AlertDialog.Builder(this).setTitle("Face")
                .setItems(faces) { _, w ->
                    inst.props[key] = faces[w]; viewport.invalidate(); refreshPanels()
                }.show()
            return
        }

        val hint = when (current) {
            is Vector3 -> "x, y, z"
            is Color3 -> "r, g, b  (0-255)"
            is Float -> "nombre"
            else -> "texte"
        }
        promptText("$key  ($hint)", current.toString()) { txt ->
            val parsed: Any? = when (current) {
                is Vector3 -> Vector3.parse(txt)
                is Color3 -> Color3.parse(txt)
                is Float -> txt.trim().toFloatOrNull()
                else -> txt
            }
            if (parsed == null) {
                Studio.log("Valeur invalide pour $key", 2)
            } else {
                inst.props[key] = parsed
                viewport.invalidate(); refreshPanels()
            }
        }
    }

    // ---------------------------------------------------------------- attributes

    private fun setupAttrs() {
        val list = findViewById<RecyclerView>(R.id.listAttrs)
        list.layoutManager = LinearLayoutManager(this)
        attrsAdapter = KeyValueAdapter(
            onClick = { key -> editAttribute(key) },
            onLongClick = { key ->
                val inst = Studio.selected ?: return@KeyValueAdapter
                AlertDialog.Builder(this)
                    .setTitle("Supprimer l'attribut \"$key\" ?")
                    .setPositiveButton("Supprimer") { _, _ ->
                        inst.attributes.remove(key); refreshPanels()
                    }
                    .setNegativeButton("Annuler", null).show()
            }
        )
        list.adapter = attrsAdapter
    }

    private fun editAttribute(key: String) {
        val inst = Studio.selected ?: return
        val current = inst.attributes[key] ?: return
        if (current is Boolean) {
            inst.attributes[key] = !current; refreshPanels(); return
        }
        promptText(key, current.toString()) { txt ->
            val parsed: Any? = when (current) {
                is Vector3 -> Vector3.parse(txt)
                is Color3 -> Color3.parse(txt)
                is Float -> txt.trim().toFloatOrNull()
                else -> txt
            }
            if (parsed == null) Studio.log("Valeur invalide", 2)
            else { inst.attributes[key] = parsed; refreshPanels() }
        }
    }

    private fun showAddAttributeDialog() {
        val inst = Studio.selected
        if (inst == null) { Studio.log("Sélectionne d'abord une instance", 1); return }
        val types = arrayOf("Texte", "Nombre", "Booléen", "Vector3", "Color3")
        AlertDialog.Builder(this)
            .setTitle("Type de l'attribut")
            .setItems(types) { _, which ->
                promptText("Nom de l'attribut", "") { name ->
                    if (name.isBlank()) return@promptText
                    inst.attributes[name] = when (which) {
                        1 -> 0f
                        2 -> false
                        3 -> Vector3(0f, 0f, 0f)
                        4 -> Color3.fromRGB(255, 255, 255)
                        else -> ""
                    }
                    refreshPanels()
                }
            }.show()
    }

    // ---------------------------------------------------------------- output

    private fun setupOutput() {
        outputList = findViewById(R.id.listOutput)
        outputList.layoutManager = LinearLayoutManager(this)
        outputAdapter = OutputAdapter()
        outputList.adapter = outputAdapter
        outputAdapter.refresh()
    }

    // ---------------------------------------------------------------- script

    private var editingScript: RInstance? = null

    private fun saveScriptEdits() {
        val s = editingScript ?: return
        s.props["Source"] = scriptEditor.text.toString()
    }

    private fun loadScriptPanel() {
        val sel = Studio.selected
        if (sel != null && (sel.className == "Script" || sel.className == "LocalScript")) {
            if (editingScript !== sel) {
                saveScriptEdits()
                editingScript = sel
                scriptEditor.setText(sel.props["Source"]?.toString() ?: "")
            }
            scriptTitle.text = sel.fullName()
            scriptEditor.isEnabled = true
        } else {
            saveScriptEdits()
            editingScript = null
            scriptTitle.text = "Sélectionne un Script dans l'Explorer"
            scriptEditor.setText("")
            scriptEditor.isEnabled = false
        }
    }

    // ---------------------------------------------------------------- commun

    private fun refreshPanels() {
        val inst = Studio.selected
        if (inst == null) {
            propsAdapter.setData(emptyMap())
            attrsAdapter.setData(emptyMap())
        } else {
            propsAdapter.setData(
                inst.props,
                listOf("Name" to inst.name, "ClassName" to inst.className)
            )
            attrsAdapter.setData(inst.attributes)
        }
        loadScriptPanel()
    }

    private fun promptText(title: String, initial: String, onOk: (String) -> Unit) {
        val input = EditText(this)
        input.setText(initial)
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.setSelection(input.text.length)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("OK") { _, _ -> onOk(input.text.toString()) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---------------------------------------------------------------- persistance

    private fun loadPlace() {
        try {
            if (saveFile.exists()) {
                Studio.setRoot(Serializer.fromJson(JSONObject(saveFile.readText())))
                return
            }
        } catch (_: Exception) { }
        Studio.buildDefaultPlace()
    }

    private fun savePlace() {
        try {
            saveFile.writeText(Serializer.toJson(Studio.game).toString())
        } catch (_: Exception) { }
    }

    override fun onPause() {
        super.onPause()
        saveScriptEdits()
        savePlace()
    }

    override fun onDestroy() {
        lua.stop()
        super.onDestroy()
    }
}

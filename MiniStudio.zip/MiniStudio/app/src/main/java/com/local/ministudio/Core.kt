package com.local.ministudio

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

// ---------------------------------------------------------------- types de base

data class Vector3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(o: Vector3) = Vector3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: Vector3) = Vector3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Float) = Vector3(x * s, y * s, z * s)
    fun dot(o: Vector3) = x * o.x + y * o.y + z * o.z
    fun cross(o: Vector3) = Vector3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
    fun length() = sqrt(dot(this))
    fun unit(): Vector3 {
        val l = length()
        return if (l < 1e-6f) Vector3(0f, 0f, 0f) else Vector3(x / l, y / l, z / l)
    }
    override fun toString() = fmt(x) + ", " + fmt(y) + ", " + fmt(z)

    companion object {
        fun fmt(v: Float): String {
            return if (abs(v - v.toInt()) < 0.005f) v.toInt().toString()
            else String.format("%.2f", v)
        }
        fun parse(s: String): Vector3? {
            val p = s.split(",").map { it.trim() }
            if (p.size != 3) return null
            val a = p[0].toFloatOrNull() ?: return null
            val b = p[1].toFloatOrNull() ?: return null
            val c = p[2].toFloatOrNull() ?: return null
            return Vector3(a, b, c)
        }
    }
}

data class Color3(val r: Float, val g: Float, val b: Float) {
    fun toArgb(): Int = android.graphics.Color.rgb(
        (r * 255f).toInt().coerceIn(0, 255),
        (g * 255f).toInt().coerceIn(0, 255),
        (b * 255f).toInt().coerceIn(0, 255)
    )
    override fun toString() =
        "${(r * 255).toInt()}, ${(g * 255).toInt()}, ${(b * 255).toInt()}"

    companion object {
        fun fromRGB(r: Int, g: Int, b: Int) = Color3(r / 255f, g / 255f, b / 255f)
        fun parse(s: String): Color3? {
            val p = s.split(",").map { it.trim() }
            if (p.size != 3) return null
            val a = p[0].toIntOrNull() ?: return null
            val b = p[1].toIntOrNull() ?: return null
            val c = p[2].toIntOrNull() ?: return null
            return fromRGB(a, b, c)
        }
    }
}

// ---------------------------------------------------------------- Instance

class RInstance(val className: String) {
    var name: String = className
    var parent: RInstance? = null
        private set
    val children = ArrayList<RInstance>()
    val props = LinkedHashMap<String, Any>()
    val attributes = LinkedHashMap<String, Any>()

    // utilise par l'explorer pour plier / deplier
    var expanded = true

    fun setParent(p: RInstance?) {
        parent?.children?.remove(this)
        parent = p
        p?.children?.add(this)
    }

    fun destroy() {
        for (c in ArrayList(children)) c.destroy()
        parent?.children?.remove(this)
        parent = null
    }

    fun findFirstChild(n: String): RInstance? = children.firstOrNull { it.name == n }

    fun descendants(): List<RInstance> {
        val out = ArrayList<RInstance>()
        fun walk(i: RInstance) {
            for (c in i.children) { out.add(c); walk(c) }
        }
        walk(this)
        return out
    }

    fun fullName(): String {
        val parts = ArrayList<String>()
        var cur: RInstance? = this
        while (cur != null) { parts.add(0, cur.name); cur = cur.parent }
        return parts.joinToString(".")
    }

    fun isA(cls: String): Boolean {
        if (className == cls) return true
        return when (cls) {
            "BasePart" -> className == "Part"
            "GuiObject" -> className == "TextLabel" || className == "Frame"
            "LuaSourceContainer" -> className == "Script" || className == "LocalScript"
            "Instance" -> true
            else -> false
        }
    }

    fun clone(): RInstance {
        val c = RInstance(className)
        c.name = name
        c.props.putAll(props)
        c.attributes.putAll(attributes)
        for (child in children) child.clone().setParent(c)
        return c
    }

    companion object {
        val CREATABLE = listOf(
            "Part", "Model", "Folder", "SurfaceGui", "TextLabel", "Frame",
            "Script", "LocalScript", "Value"
        )

        fun new(className: String): RInstance {
            val i = RInstance(className)
            i.name = className
            when (className) {
                "Part" -> {
                    i.props["Position"] = Vector3(0f, 4f, 0f)
                    i.props["Size"] = Vector3(4f, 1f, 2f)
                    i.props["Orientation"] = Vector3(0f, 0f, 0f)
                    i.props["Color"] = Color3.fromRGB(163, 162, 165)
                    i.props["Transparency"] = 0f
                    i.props["Anchored"] = true
                    i.props["CanCollide"] = true
                }
                "SurfaceGui" -> {
                    i.props["Face"] = "Front"
                    i.props["Enabled"] = true
                }
                "TextLabel" -> {
                    i.props["Text"] = "Label"
                    i.props["TextColor3"] = Color3.fromRGB(255, 255, 255)
                    i.props["BackgroundColor3"] = Color3.fromRGB(30, 30, 30)
                    i.props["BackgroundTransparency"] = 0f
                    i.props["TextSize"] = 24f
                }
                "Frame" -> {
                    i.props["BackgroundColor3"] = Color3.fromRGB(60, 120, 200)
                    i.props["BackgroundTransparency"] = 0f
                }
                "Script", "LocalScript" -> {
                    i.props["Source"] = "print(\"Hello world\")\n"
                    i.props["Enabled"] = true
                }
                "Value" -> {
                    i.props["Value"] = 0f
                }
            }
            return i
        }
    }
}

// ---------------------------------------------------------------- serialisation

object Serializer {

    private fun valueToJson(v: Any): JSONObject {
        val o = JSONObject()
        when (v) {
            is Vector3 -> { o.put("t", "v3"); o.put("x", v.x.toDouble()); o.put("y", v.y.toDouble()); o.put("z", v.z.toDouble()) }
            is Color3 -> { o.put("t", "c3"); o.put("r", v.r.toDouble()); o.put("g", v.g.toDouble()); o.put("b", v.b.toDouble()) }
            is Float -> { o.put("t", "n"); o.put("v", v.toDouble()) }
            is Boolean -> { o.put("t", "b"); o.put("v", v) }
            else -> { o.put("t", "s"); o.put("v", v.toString()) }
        }
        return o
    }

    private fun jsonToValue(o: JSONObject): Any = when (o.getString("t")) {
        "v3" -> Vector3(o.getDouble("x").toFloat(), o.getDouble("y").toFloat(), o.getDouble("z").toFloat())
        "c3" -> Color3(o.getDouble("r").toFloat(), o.getDouble("g").toFloat(), o.getDouble("b").toFloat())
        "n" -> o.getDouble("v").toFloat()
        "b" -> o.getBoolean("v")
        else -> o.getString("v")
    }

    fun toJson(inst: RInstance): JSONObject {
        val o = JSONObject()
        o.put("class", inst.className)
        o.put("name", inst.name)
        val p = JSONObject()
        for ((k, v) in inst.props) p.put(k, valueToJson(v))
        o.put("props", p)
        val a = JSONObject()
        for ((k, v) in inst.attributes) a.put(k, valueToJson(v))
        o.put("attrs", a)
        val ch = JSONArray()
        for (c in inst.children) ch.put(toJson(c))
        o.put("children", ch)
        return o
    }

    fun fromJson(o: JSONObject): RInstance {
        val inst = RInstance(o.getString("class"))
        inst.name = o.getString("name")
        val p = o.getJSONObject("props")
        for (k in p.keys()) inst.props[k] = jsonToValue(p.getJSONObject(k))
        val a = o.getJSONObject("attrs")
        for (k in a.keys()) inst.attributes[k] = jsonToValue(a.getJSONObject(k))
        val ch = o.getJSONArray("children")
        for (idx in 0 until ch.length()) fromJson(ch.getJSONObject(idx)).setParent(inst)
        return inst
    }
}

// ---------------------------------------------------------------- etat global

object Studio {

    lateinit var game: RInstance
    lateinit var workspace: RInstance

    /** vrai des qu'une place est chargee (lateinit non accessible hors fichier) */
    var ready = false
        private set

    fun setRoot(root: RInstance) {
        game = root
        workspace = root.findFirstChild("Workspace") ?: RInstance("Workspace").also {
            it.name = "Workspace"; it.setParent(root)
        }
        ready = true
    }

    var selected: RInstance? = null

    val output = ArrayList<OutputLine>()
    var onOutputChanged: (() -> Unit)? = null
    var onTreeChanged: (() -> Unit)? = null

    class OutputLine(val text: String, val level: Int) // 0 info, 1 warn, 2 error

    fun log(text: String, level: Int = 0) {
        synchronized(output) {
            output.add(OutputLine(text, level))
            if (output.size > 500) output.removeAt(0)
        }
        onOutputChanged?.invoke()
    }

    fun clearOutput() {
        synchronized(output) { output.clear() }
        onOutputChanged?.invoke()
    }

    fun buildDefaultPlace() {
        ready = false
        game = RInstance("DataModel")
        game.name = "game"

        workspace = RInstance("Workspace")
        workspace.name = "Workspace"
        workspace.setParent(game)

        val lighting = RInstance("Lighting"); lighting.name = "Lighting"; lighting.setParent(game)
        val rs = RInstance("ReplicatedStorage"); rs.name = "ReplicatedStorage"; rs.setParent(game)
        val sss = RInstance("ServerScriptService"); sss.name = "ServerScriptService"; sss.setParent(game)

        val base = RInstance.new("Part")
        base.name = "Baseplate"
        base.props["Size"] = Vector3(40f, 1f, 40f)
        base.props["Position"] = Vector3(0f, -0.5f, 0f)
        base.props["Color"] = Color3.fromRGB(91, 154, 76)
        base.setParent(workspace)

        val part = RInstance.new("Part")
        part.name = "Part"
        part.props["Position"] = Vector3(0f, 2f, 0f)
        part.props["Size"] = Vector3(4f, 4f, 4f)
        part.props["Color"] = Color3.fromRGB(196, 40, 28)
        part.setParent(workspace)

        val gui = RInstance.new("SurfaceGui")
        gui.props["Face"] = "Front"
        gui.setParent(part)

        val label = RInstance.new("TextLabel")
        label.props["Text"] = "Hello!"
        label.props["BackgroundColor3"] = Color3.fromRGB(20, 20, 20)
        label.setParent(gui)

        val script = RInstance.new("Script")
        script.name = "DemoScript"
        script.props["Source"] = """
-- Exemple : tourne et colore la Part
local part = workspace:FindFirstChild("Part")
print("Script lance sur " .. part.Name)

part:SetAttribute("Vitesse", 5)
print("Attribut Vitesse =", part:GetAttribute("Vitesse"))

for i = 1, 20 do
    part.Orientation = Vector3.new(0, i * 18, 0)
    part.Color = Color3.fromRGB(255 - i * 10, 40, i * 10)
    local gui = part:FindFirstChild("SurfaceGui")
    gui.TextLabel.Text = "Tick " .. i
    task.wait(0.1)
end

print("Termine")
""".trimIndent()
        script.setParent(sss)

        selected = part
        ready = true
    }

    fun findByPath(path: String): RInstance? {
        val parts = path.split(".")
        if (parts.isEmpty()) return null
        var cur: RInstance = game
        for (i in 1 until parts.size) {
            cur = cur.findFirstChild(parts[i]) ?: return null
        }
        return cur
    }
}

// ---------------------------------------------------------------- maths rotation

object Mat {
    /** rotation euler YXZ (degres), comme Orientation dans Roblox */
    fun rotate(v: Vector3, ori: Vector3): Vector3 {
        val rx = Math.toRadians(ori.x.toDouble()).toFloat()
        val ry = Math.toRadians(ori.y.toDouble()).toFloat()
        val rz = Math.toRadians(ori.z.toDouble()).toFloat()
        // Rz
        var x = v.x * cos(rz) - v.y * sin(rz)
        var y = v.x * sin(rz) + v.y * cos(rz)
        var z = v.z
        // Rx
        val y2 = y * cos(rx) - z * sin(rx)
        val z2 = y * sin(rx) + z * cos(rx)
        y = y2; z = z2
        // Ry
        val x3 = x * cos(ry) + z * sin(ry)
        val z3 = -x * sin(ry) + z * cos(ry)
        x = x3; z = z3
        return Vector3(x, y, z)
    }

    /** rotation inverse (transposee) */
    fun unrotate(v: Vector3, ori: Vector3): Vector3 {
        val rx = Math.toRadians(ori.x.toDouble()).toFloat()
        val ry = Math.toRadians(ori.y.toDouble()).toFloat()
        val rz = Math.toRadians(ori.z.toDouble()).toFloat()
        // Ry^-1
        var x = v.x * cos(-ry) + v.z * sin(-ry)
        var z = -v.x * sin(-ry) + v.z * cos(-ry)
        var y = v.y
        // Rx^-1
        val y2 = y * cos(-rx) - z * sin(-rx)
        val z2 = y * sin(-rx) + z * cos(-rx)
        y = y2; z = z2
        // Rz^-1
        val x3 = x * cos(-rz) - y * sin(-rz)
        val y3 = x * sin(-rz) + y * cos(-rz)
        x = x3; y = y3
        return Vector3(x, y, z)
    }
}

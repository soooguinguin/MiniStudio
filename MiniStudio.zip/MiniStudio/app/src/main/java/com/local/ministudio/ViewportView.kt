package com.local.ministudio

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Petit moteur de rendu 3D logiciel (pas d'OpenGL, pas de dependance).
 * Dessine des boites (Part) avec l'algorithme du peintre.
 */
class ViewportView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var onSelect: ((RInstance?) -> Unit)? = null

    // camera orbitale
    private var yaw = 0.7f
    private var pitch = 0.45f
    private var dist = 32f
    private var target = Vector3(0f, 2f, 0f)

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.5f; color = Color.argb(70, 0, 0, 0)
    }
    private val selPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.parseColor("#3794FF")
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1f; color = Color.argb(45, 255, 255, 255)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
    }
    private val hudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8A8A8A"); textSize = 26f
    }

    private var camPos = Vector3(0f, 0f, 0f)
    private var right = Vector3(1f, 0f, 0f)
    private var up = Vector3(0f, 1f, 0f)
    private var fwd = Vector3(0f, 0f, 1f)
    private var focal = 700f

    private val lightDir = Vector3(-0.4f, -1f, -0.35f).unit()

    // --------------------------------------------------------------- camera

    private fun updateCamera() {
        val cx = target.x + dist * cos(pitch) * sin(yaw)
        val cy = target.y + dist * sin(pitch)
        val cz = target.z + dist * cos(pitch) * cos(yaw)
        camPos = Vector3(cx, cy, cz)
        fwd = (target - camPos).unit()
        right = fwd.cross(Vector3(0f, 1f, 0f)).unit()
        up = right.cross(fwd).unit()
        focal = min(width, height) * 1.1f
    }

    private fun toView(p: Vector3): Vector3 {
        val d = p - camPos
        return Vector3(d.dot(right), d.dot(up), d.dot(fwd))
    }

    private fun project(v: Vector3): FloatArray? {
        if (v.z < 0.15f) return null
        val sx = width / 2f + focal * v.x / v.z
        val sy = height / 2f - focal * v.y / v.z
        return floatArrayOf(sx, sy)
    }

    // --------------------------------------------------------------- geometrie

    private val corners = arrayOf(
        Vector3(-1f, -1f, -1f), Vector3(1f, -1f, -1f), Vector3(1f, 1f, -1f), Vector3(-1f, 1f, -1f),
        Vector3(-1f, -1f, 1f), Vector3(1f, -1f, 1f), Vector3(1f, 1f, 1f), Vector3(-1f, 1f, 1f)
    )

    // face -> (indices des 4 coins, normale locale, nom de face Roblox)
    private val faces = listOf(
        Triple(intArrayOf(4, 5, 6, 7), Vector3(0f, 0f, 1f), "Back"),
        Triple(intArrayOf(1, 0, 3, 2), Vector3(0f, 0f, -1f), "Front"),
        Triple(intArrayOf(5, 1, 2, 6), Vector3(1f, 0f, 0f), "Right"),
        Triple(intArrayOf(0, 4, 7, 3), Vector3(-1f, 0f, 0f), "Left"),
        Triple(intArrayOf(3, 7, 6, 2), Vector3(0f, 1f, 0f), "Top"),
        Triple(intArrayOf(0, 1, 5, 4), Vector3(0f, -1f, 0f), "Bottom")
    )

    private class Poly(
        val depth: Float,
        val pts: FloatArray,       // 8 valeurs : x1,y1,...x4,y4
        val color: Int,
        val alpha: Int,
        val selected: Boolean,
        val gui: RInstance?,       // SurfaceGui a dessiner sur cette face
        val cx: Float, val cy: Float, val faceSize: Float
    )

    // --------------------------------------------------------------- dessin

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.parseColor("#20252B"))
        if (!Studio.ready) return
        updateCamera()

        drawGrid(canvas)

        val polys = ArrayList<Poly>()
        for (inst in Studio.workspace.descendants()) {
            if (inst.className != "Part") continue
            collectPart(inst, polys)
        }
        polys.sortByDescending { it.depth }

        val path = Path()
        for (p in polys) {
            path.reset()
            path.moveTo(p.pts[0], p.pts[1])
            path.lineTo(p.pts[2], p.pts[3])
            path.lineTo(p.pts[4], p.pts[5])
            path.lineTo(p.pts[6], p.pts[7])
            path.close()

            fill.color = p.color
            fill.alpha = p.alpha
            canvas.drawPath(path, fill)
            canvas.drawPath(path, stroke)

            if (p.gui != null) drawSurfaceGui(canvas, p, path)
            if (p.selected) canvas.drawPath(path, selPaint)
        }

        canvas.drawText("1 doigt = tourner  •  2 doigts = zoom  •  tap = selectionner", 18f, height - 18f, hudPaint)
    }

    private fun drawGrid(canvas: Canvas) {
        val n = 20
        for (i in -n..n step 2) {
            line(canvas, Vector3(i.toFloat(), 0f, -n.toFloat()), Vector3(i.toFloat(), 0f, n.toFloat()))
            line(canvas, Vector3(-n.toFloat(), 0f, i.toFloat()), Vector3(n.toFloat(), 0f, i.toFloat()))
        }
    }

    private fun line(canvas: Canvas, a: Vector3, b: Vector3) {
        val va = toView(a); val vb = toView(b)
        val pa = project(va) ?: return
        val pb = project(vb) ?: return
        canvas.drawLine(pa[0], pa[1], pb[0], pb[1], gridPaint)
    }

    private fun collectPart(part: RInstance, out: ArrayList<Poly>) {
        val pos = part.props["Position"] as? Vector3 ?: return
        val size = part.props["Size"] as? Vector3 ?: return
        val ori = part.props["Orientation"] as? Vector3 ?: Vector3(0f, 0f, 0f)
        val col = (part.props["Color"] as? Color3)?.toArgb() ?: Color.GRAY
        val transparency = (part.props["Transparency"] as? Float) ?: 0f
        if (transparency >= 0.98f) return
        val alpha = ((1f - transparency) * 255).toInt().coerceIn(0, 255)
        val isSel = Studio.selected === part

        val world = Array(8) { i ->
            val c = corners[i]
            pos + Mat.rotate(Vector3(c.x * size.x / 2f, c.y * size.y / 2f, c.z * size.z / 2f), ori)
        }
        val view = Array(8) { toView(world[it]) }

        val guis = part.children.filter {
            it.className == "SurfaceGui" && (it.props["Enabled"] as? Boolean ?: true)
        }

        for (f in faces) {
            val (ind, localNormal, faceName) = f
            val normal = Mat.rotate(localNormal, ori)
            val center = (world[ind[0]] + world[ind[1]] + world[ind[2]] + world[ind[3]]) * 0.25f
            // backface culling
            if (normal.dot((center - camPos).unit()) > 0f) continue

            val pts = FloatArray(8)
            var ok = true
            var depth = 0f
            for (k in 0..3) {
                val v = view[ind[k]]
                val p = project(v)
                if (p == null) { ok = false; break }
                pts[k * 2] = p[0]; pts[k * 2 + 1] = p[1]
                depth += v.z
            }
            if (!ok) continue
            depth /= 4f

            val shade = (0.45f + 0.55f * max(0f, -normal.dot(lightDir))).coerceIn(0f, 1f)
            val shaded = Color.rgb(
                (Color.red(col) * shade).toInt().coerceIn(0, 255),
                (Color.green(col) * shade).toInt().coerceIn(0, 255),
                (Color.blue(col) * shade).toInt().coerceIn(0, 255)
            )

            val gui = guis.firstOrNull { (it.props["Face"] as? String ?: "Front") == faceName }
            val ccx = (pts[0] + pts[2] + pts[4] + pts[6]) / 4f
            val ccy = (pts[1] + pts[3] + pts[5] + pts[7]) / 4f
            val fs = hypot(pts[2] - pts[0], pts[3] - pts[1])

            out.add(Poly(depth, pts, shaded, alpha, isSel, gui, ccx, ccy, fs))
        }
    }

    /** Rendu simplifie d'une SurfaceGui : fond + texte centre sur la face. */
    private fun drawSurfaceGui(canvas: Canvas, p: Poly, path: Path) {
        val gui = p.gui ?: return
        canvas.save()
        canvas.clipPath(path)
        for (child in gui.children) {
            when (child.className) {
                "Frame", "TextLabel" -> {
                    val bg = (child.props["BackgroundColor3"] as? Color3)?.toArgb() ?: Color.BLACK
                    val bt = (child.props["BackgroundTransparency"] as? Float) ?: 0f
                    fill.color = bg
                    fill.alpha = ((1f - bt) * 255).toInt().coerceIn(0, 255)
                    canvas.drawPath(path, fill)
                }
            }
            if (child.className == "TextLabel") {
                val txt = child.props["Text"]?.toString() ?: ""
                textPaint.color = (child.props["TextColor3"] as? Color3)?.toArgb() ?: Color.WHITE
                textPaint.textSize = (p.faceSize * 0.18f).coerceIn(8f, 90f)
                canvas.drawText(txt, p.cx, p.cy + textPaint.textSize / 3f, textPaint)
            }
        }
        canvas.restore()
    }

    // --------------------------------------------------------------- interaction

    private var lastX = 0f
    private var lastY = 0f
    private var lastDist = 0f
    private var downX = 0f
    private var downY = 0f
    private var moved = false

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x; lastY = event.y
                downX = event.x; downY = event.y
                moved = false
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                lastDist = spacing(event); moved = true
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2) {
                    val d = spacing(event)
                    if (lastDist > 0f) {
                        dist = (dist * (lastDist / d)).coerceIn(5f, 200f)
                        invalidate()
                    }
                    lastDist = d
                } else {
                    val dx = event.x - lastX
                    val dy = event.y - lastY
                    yaw -= dx * 0.008f
                    pitch = (pitch + dy * 0.008f).coerceIn(-1.45f, 1.45f)
                    lastX = event.x; lastY = event.y
                    if (abs(event.x - downX) > 12 || abs(event.y - downY) > 12) moved = true
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) pick(event.x, event.y)
            }
        }
        return true
    }

    private fun spacing(e: MotionEvent): Float {
        val dx = e.getX(0) - e.getX(1)
        val dy = e.getY(0) - e.getY(1)
        return hypot(dx, dy)
    }

    /** Lance un rayon depuis le tap et selectionne la Part touchee. */
    private fun pick(sx: Float, sy: Float) {
        updateCamera()
        val ndx = (sx - width / 2f) / focal
        val ndy = -(sy - height / 2f) / focal
        val dir = (right * ndx + up * ndy + fwd).unit()

        var best: RInstance? = null
        var bestT = Float.MAX_VALUE

        for (inst in Studio.workspace.descendants()) {
            if (inst.className != "Part") continue
            val pos = inst.props["Position"] as? Vector3 ?: continue
            val size = inst.props["Size"] as? Vector3 ?: continue
            val ori = inst.props["Orientation"] as? Vector3 ?: Vector3(0f, 0f, 0f)

            val o = Mat.unrotate(camPos - pos, ori)
            val d = Mat.unrotate(dir, ori)
            val t = intersectBox(o, d, size * 0.5f) ?: continue
            if (t < bestT) { bestT = t; best = inst }
        }

        Studio.selected = best
        onSelect?.invoke(best)
        invalidate()
    }

    private fun intersectBox(o: Vector3, d: Vector3, half: Vector3): Float? {
        var tmin = -Float.MAX_VALUE
        var tmax = Float.MAX_VALUE
        val od = floatArrayOf(o.x, o.y, o.z)
        val dd = floatArrayOf(d.x, d.y, d.z)
        val hd = floatArrayOf(half.x, half.y, half.z)
        for (i in 0..2) {
            if (abs(dd[i]) < 1e-6f) {
                if (od[i] < -hd[i] || od[i] > hd[i]) return null
            } else {
                var t1 = (-hd[i] - od[i]) / dd[i]
                var t2 = (hd[i] - od[i]) / dd[i]
                if (t1 > t2) { val tmp = t1; t1 = t2; t2 = tmp }
                tmin = max(tmin, t1)
                tmax = min(tmax, t2)
                if (tmin > tmax) return null
            }
        }
        return if (tmax < 0f) null else max(tmin, 0f)
    }

    fun focusOnSelection() {
        val sel = Studio.selected ?: return
        val pos = sel.props["Position"] as? Vector3 ?: return
        target = pos
        invalidate()
    }
}

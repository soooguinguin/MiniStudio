package com.local.ministudio

import org.luaj.vm2.LuaError
import org.luaj.vm2.LuaTable
import org.luaj.vm2.LuaValue
import org.luaj.vm2.Varargs
import org.luaj.vm2.lib.OneArgFunction
import org.luaj.vm2.lib.ThreeArgFunction
import org.luaj.vm2.lib.TwoArgFunction
import org.luaj.vm2.lib.VarArgFunction
import org.luaj.vm2.lib.jse.JsePlatform

/**
 * Execute du Lua reel (LuaJ) avec une petite API facon Roblox
 * branchee sur l'arbre d'instances du Studio.
 */
class LuaRunner(private val onRedraw: () -> Unit) {

    @Volatile private var stopped = false
    private var thread: Thread? = null
    private val wrapped = HashMap<RInstance, LuaTable>()

    val isRunning: Boolean get() = thread?.isAlive == true

    fun stop() {
        stopped = true
        thread?.interrupt()
    }

    fun runAllScripts() {
        val scripts = Studio.game.descendants().filter {
            (it.className == "Script" || it.className == "LocalScript") &&
                (it.props["Enabled"] as? Boolean ?: true)
        }
        if (scripts.isEmpty()) {
            Studio.log("Aucun Script actif a executer", 1)
            return
        }
        run(scripts)
    }

    fun runScript(script: RInstance) = run(listOf(script))

    private fun run(scripts: List<RInstance>) {
        if (isRunning) {
            Studio.log("Un script tourne deja — appuie sur Stop", 1)
            return
        }
        stopped = false
        wrapped.clear()
        thread = Thread {
            val globals = JsePlatform.debugGlobals()
            installApi(globals)
            for (s in scripts) {
                if (stopped) break
                val src = s.props["Source"]?.toString() ?: continue
                Studio.log("▶ ${s.fullName()}", 0)
                try {
                    val chunk = globals.load(src, s.name)
                    chunk.call()
                } catch (e: LuaError) {
                    val msg = e.message ?: "erreur"
                    if (stopped && msg.contains("__stop__")) {
                        Studio.log("■ Script arrete", 1)
                    } else {
                        Studio.log("✖ ${s.name}: $msg", 2)
                    }
                } catch (e: InterruptedException) {
                    Studio.log("■ Script arrete", 1)
                } catch (e: Exception) {
                    Studio.log("✖ ${s.name}: ${e.message}", 2)
                }
            }
            onRedraw()
        }
        thread!!.start()
    }

    // ------------------------------------------------------------- conversions

    private fun makeVector3(v: Vector3): LuaTable {
        val t = LuaTable()
        t.set("x", LuaValue.valueOf(v.x.toDouble()))
        t.set("y", LuaValue.valueOf(v.y.toDouble()))
        t.set("z", LuaValue.valueOf(v.z.toDouble()))
        t.set("X", LuaValue.valueOf(v.x.toDouble()))
        t.set("Y", LuaValue.valueOf(v.y.toDouble()))
        t.set("Z", LuaValue.valueOf(v.z.toDouble()))
        t.set("__type", LuaValue.valueOf("Vector3"))
        return t
    }

    private fun makeColor3(c: Color3): LuaTable {
        val t = LuaTable()
        t.set("r", LuaValue.valueOf(c.r.toDouble()))
        t.set("g", LuaValue.valueOf(c.g.toDouble()))
        t.set("b", LuaValue.valueOf(c.b.toDouble()))
        t.set("R", LuaValue.valueOf(c.r.toDouble()))
        t.set("G", LuaValue.valueOf(c.g.toDouble()))
        t.set("B", LuaValue.valueOf(c.b.toDouble()))
        t.set("__type", LuaValue.valueOf("Color3"))
        return t
    }

    private fun toLua(v: Any?): LuaValue = when (v) {
        null -> LuaValue.NIL
        is Vector3 -> makeVector3(v)
        is Color3 -> makeColor3(v)
        is Float -> LuaValue.valueOf(v.toDouble())
        is Double -> LuaValue.valueOf(v)
        is Int -> LuaValue.valueOf(v.toDouble())
        is Boolean -> LuaValue.valueOf(v)
        is RInstance -> wrap(v)
        else -> LuaValue.valueOf(v.toString())
    }

    private fun fromLua(v: LuaValue): Any? {
        if (v.isnil()) return null
        if (v.isboolean()) return v.toboolean()
        if (v.isnumber()) return v.todouble().toFloat()
        if (v.isstring()) return v.tojstring()
        if (v.istable()) {
            val t = v.checktable()
            when (t.get("__type").optjstring("")) {
                "Vector3" -> return Vector3(
                    t.get("x").todouble().toFloat(),
                    t.get("y").todouble().toFloat(),
                    t.get("z").todouble().toFloat()
                )
                "Color3" -> return Color3(
                    t.get("r").todouble().toFloat(),
                    t.get("g").todouble().toFloat(),
                    t.get("b").todouble().toFloat()
                )
            }
            for ((inst, table) in wrapped) if (table === t) return inst
        }
        return null
    }

    private fun luaToDisplay(v: LuaValue): String {
        if (v.istable()) {
            val t = v.checktable()
            when (t.get("__type").optjstring("")) {
                "Vector3" -> return (fromLua(v) as Vector3).toString()
                "Color3" -> return (fromLua(v) as Color3).toString()
            }
            for ((inst, table) in wrapped) if (table === t) return inst.name
        }
        return v.tojstring()
    }

    // ------------------------------------------------------------- wrapping Instance

    private fun wrap(inst: RInstance): LuaTable {
        wrapped[inst]?.let { return it }
        val t = LuaTable()

        val mt = LuaTable()
        mt.set("__index", object : TwoArgFunction() {
            override fun call(self: LuaValue, key: LuaValue): LuaValue {
                val k = key.tojstring()
                when (k) {
                    "Name" -> return LuaValue.valueOf(inst.name)
                    "ClassName" -> return LuaValue.valueOf(inst.className)
                    "Parent" -> return inst.parent?.let { wrap(it) } ?: LuaValue.NIL
                }
                methodFor(inst, k)?.let { return it }
                if (inst.props.containsKey(k)) return toLua(inst.props[k])
                inst.findFirstChild(k)?.let { return wrap(it) }
                throw LuaError("$k n'est pas un membre valide de ${inst.name}")
            }
        })

        mt.set("__newindex", object : ThreeArgFunction() {
            override fun call(self: LuaValue, key: LuaValue, value: LuaValue): LuaValue {
                val k = key.tojstring()
                when (k) {
                    "Name" -> { inst.name = value.tojstring(); redraw(); return LuaValue.NIL }
                    "Parent" -> {
                        inst.setParent(fromLua(value) as? RInstance)
                        redraw(); return LuaValue.NIL
                    }
                }
                if (inst.props.containsKey(k)) {
                    val old = inst.props[k]
                    val nv = fromLua(value)
                        ?: throw LuaError("valeur invalide pour $k")
                    if (old != null && old::class != nv::class) {
                        throw LuaError("mauvais type pour $k")
                    }
                    inst.props[k] = nv
                    redraw()
                    return LuaValue.NIL
                }
                throw LuaError("$k n'est pas une propriete modifiable de ${inst.name}")
            }
        })

        mt.set("__tostring", object : OneArgFunction() {
            override fun call(arg: LuaValue): LuaValue = LuaValue.valueOf(inst.name)
        })

        t.setmetatable(mt)
        wrapped[inst] = t
        return t
    }

    private fun methodFor(inst: RInstance, name: String): LuaValue? = when (name) {

        "FindFirstChild" -> object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val child = inst.findFirstChild(args.arg(2).tojstring())
                return child?.let { wrap(it) } ?: LuaValue.NIL
            }
        }

        "WaitForChild" -> object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val child = inst.findFirstChild(args.arg(2).tojstring())
                    ?: throw LuaError("enfant introuvable: ${args.arg(2).tojstring()}")
                return wrap(child)
            }
        }

        "GetChildren" -> object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val t = LuaTable()
                for ((i, c) in inst.children.withIndex()) t.set(i + 1, wrap(c))
                return t
            }
        }

        "GetDescendants" -> object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val t = LuaTable()
                for ((i, c) in inst.descendants().withIndex()) t.set(i + 1, wrap(c))
                return t
            }
        }

        "Destroy" -> object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                inst.destroy(); redraw(); return LuaValue.NIL
            }
        }

        "Clone" -> object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs = wrap(inst.clone())
        }

        "IsA" -> object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs =
                LuaValue.valueOf(inst.isA(args.arg(2).tojstring()))
        }

        "SetAttribute" -> object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val k = args.arg(2).tojstring()
                val v = fromLua(args.arg(3))
                if (v == null) inst.attributes.remove(k) else inst.attributes[k] = v
                redraw()
                return LuaValue.NIL
            }
        }

        "GetAttribute" -> object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs =
                toLua(inst.attributes[args.arg(2).tojstring()])
        }

        "GetAttributes" -> object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val t = LuaTable()
                for ((k, v) in inst.attributes) t.set(k, toLua(v))
                return t
            }
        }

        else -> null
    }

    private fun redraw() = onRedraw()

    private fun sleepChecked(seconds: Double) {
        val ms = (seconds * 1000).toLong().coerceAtLeast(0L)
        val step = 25L
        var slept = 0L
        while (slept < ms) {
            if (stopped) throw LuaError("__stop__")
            Thread.sleep(minOf(step, ms - slept))
            slept += step
        }
        if (stopped) throw LuaError("__stop__")
    }

    // ------------------------------------------------------------- API globale

    private fun installApi(globals: org.luaj.vm2.Globals) {

        // arret cooperatif meme dans une boucle sans wait
        try {
            val hook = object : VarArgFunction() {
                override fun invoke(args: Varargs): Varargs {
                    if (stopped) throw LuaError("__stop__")
                    return LuaValue.NONE
                }
            }
            globals.get("debug").get("sethook")
                .call(hook, LuaValue.valueOf(""), LuaValue.valueOf(3000))
        } catch (_: Exception) { }

        globals.set("print", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val sb = StringBuilder()
                for (i in 1..args.narg()) {
                    if (i > 1) sb.append("  ")
                    sb.append(luaToDisplay(args.arg(i)))
                }
                Studio.log(sb.toString(), 0)
                return LuaValue.NONE
            }
        })

        globals.set("warn", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val sb = StringBuilder()
                for (i in 1..args.narg()) {
                    if (i > 1) sb.append("  ")
                    sb.append(luaToDisplay(args.arg(i)))
                }
                Studio.log(sb.toString(), 1)
                return LuaValue.NONE
            }
        })

        val waitFn = object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val s = if (args.narg() >= 1) args.arg(1).optdouble(0.03) else 0.03
                sleepChecked(s)
                return LuaValue.valueOf(s)
            }
        }
        globals.set("wait", waitFn)

        val task = LuaTable()
        task.set("wait", waitFn)
        task.set("spawn", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                args.arg(1).call()   // execution immediate (simplifie)
                return LuaValue.NONE
            }
        })
        globals.set("task", task)

        // Vector3
        val v3 = LuaTable()
        v3.set("new", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs = makeVector3(
                Vector3(
                    args.arg(1).optdouble(0.0).toFloat(),
                    args.arg(2).optdouble(0.0).toFloat(),
                    args.arg(3).optdouble(0.0).toFloat()
                )
            )
        })
        globals.set("Vector3", v3)

        // Color3
        val c3 = LuaTable()
        c3.set("new", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs = makeColor3(
                Color3(
                    args.arg(1).optdouble(0.0).toFloat(),
                    args.arg(2).optdouble(0.0).toFloat(),
                    args.arg(3).optdouble(0.0).toFloat()
                )
            )
        })
        c3.set("fromRGB", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs = makeColor3(
                Color3.fromRGB(args.arg(1).optint(0), args.arg(2).optint(0), args.arg(3).optint(0))
            )
        })
        globals.set("Color3", c3)

        // Instance.new
        val instTable = LuaTable()
        instTable.set("new", object : VarArgFunction() {
            override fun invoke(args: Varargs): Varargs {
                val cls = args.arg(1).tojstring()
                if (cls !in RInstance.CREATABLE) throw LuaError("classe inconnue: $cls")
                val n = RInstance.new(cls)
                val p = fromLua(args.arg(2)) as? RInstance
                if (p != null) n.setParent(p)
                redraw()
                return wrap(n)
            }
        })
        globals.set("Instance", instTable)

        globals.set("game", wrap(Studio.game))
        globals.set("workspace", wrap(Studio.workspace))
        globals.set("script", LuaValue.NIL)
    }
}

package com.local.ministudio

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// ------------------------------------------------------------------ EXPLORER

class ExplorerAdapter(
    private val onClick: (RInstance) -> Unit,
    private val onLongClick: (RInstance) -> Unit
) : RecyclerView.Adapter<ExplorerAdapter.VH>() {

    class Row(val inst: RInstance, val depth: Int)

    private var rows = ArrayList<Row>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val arrow: TextView = v.findViewById(R.id.rowArrow)
        val label: TextView = v.findViewById(R.id.rowLabel)
        val cls: TextView = v.findViewById(R.id.rowClass)
    }

    fun rebuild() {
        rows = ArrayList()
        fun walk(i: RInstance, d: Int) {
            rows.add(Row(i, d))
            if (i.expanded) for (c in i.children) walk(c, d + 1)
        }
        if (Studio.ready) walk(Studio.game, 0)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.row_explorer, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val row = rows[position]
        val inst = row.inst
        holder.itemView.setPadding(12 + row.depth * 34, 0, 12, 0)
        holder.label.text = inst.name
        holder.cls.text = inst.className
        holder.arrow.text = if (inst.children.isEmpty()) "  " else if (inst.expanded) "▾" else "▸"
        holder.arrow.setOnClickListener {
            inst.expanded = !inst.expanded
            rebuild()
        }
        val isSel = Studio.selected === inst
        holder.itemView.setBackgroundColor(
            if (isSel) Color.parseColor("#0E3A5F") else Color.TRANSPARENT
        )
        holder.label.setTextColor(iconColor(inst.className))
        holder.itemView.setOnClickListener { onClick(inst) }
        holder.itemView.setOnLongClickListener { onLongClick(inst); true }
    }

    private fun iconColor(cls: String) = when (cls) {
        "Part" -> Color.parseColor("#E0E0E0")
        "Folder", "Model" -> Color.parseColor("#DCB67A")
        "Script", "LocalScript" -> Color.parseColor("#7FD67F")
        "SurfaceGui", "TextLabel", "Frame" -> Color.parseColor("#79C0FF")
        else -> Color.parseColor("#C8C8C8")
    }

    override fun getItemCount() = rows.size
}

// ------------------------------------------------------------------ PROPS / ATTRS

class KeyValueAdapter(
    private val onClick: (String) -> Unit,
    private val onLongClick: (String) -> Unit = {}
) : RecyclerView.Adapter<KeyValueAdapter.VH>() {

    private var entries = ArrayList<Pair<String, String>>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val k: TextView = v.findViewById(R.id.kvKey)
        val value: TextView = v.findViewById(R.id.kvValue)
    }

    fun setData(map: Map<String, Any>, extra: List<Pair<String, String>> = emptyList()) {
        entries = ArrayList()
        entries.addAll(extra)
        for ((k, v) in map) entries.add(k to v.toString())
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.row_kv, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val (k, v) = entries[position]
        holder.k.text = k
        holder.value.text = v
        holder.itemView.setOnClickListener { onClick(k) }
        holder.itemView.setOnLongClickListener { onLongClick(k); true }
    }

    override fun getItemCount() = entries.size
}

// ------------------------------------------------------------------ OUTPUT

class OutputAdapter : RecyclerView.Adapter<OutputAdapter.VH>() {

    private var lines = ArrayList<Studio.OutputLine>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val t: TextView = v as TextView
    }

    fun refresh() {
        lines = synchronized(Studio.output) { ArrayList(Studio.output) }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.row_output, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val l = lines[position]
        holder.t.text = l.text
        holder.t.setTextColor(
            when (l.level) {
                1 -> Color.parseColor("#FFC24D")
                2 -> Color.parseColor("#FF6B6B")
                else -> Color.parseColor("#D6D6D6")
            }
        )
    }

    override fun getItemCount() = lines.size

    fun lastIndex() = lines.size - 1
}
